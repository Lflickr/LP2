﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Psalario
{
    public partial class Form1 : Form
    {
        double salBruto;
        double aliqINSS;
        double aliqIRPF;
        double descINSS;
        double descIRPF;
        double salLiquido;
        double salFamilia;
        int qtdeFilhos;

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtNome_Validated(object sender, EventArgs e)
        {
            if(!(txtNome.Text != ""))
            {
                MessageBox.Show("O nome não pode estar vazio");
                txtNome.Focus();
            }
                
        }

        private void MskbxSalBruto_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(mskbxSalBruto.Text, out salBruto))
            {
                MessageBox.Show("O valor do salario deve ser numérico");
                mskbxSalBruto.Focus();
            }
            else if(salBruto <= 0)
            {
                MessageBox.Show("O valor do salario tem que ser maior que 0");
                mskbxSalBruto.Focus();
            }
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            //atribuir os valores
            qtdeFilhos = (int) nupdQtdeFilhos.Value;

            //calcular a aliquota do INSS
            if (salBruto <= 800.47)
            {
                aliqINSS = 0.0765;
            }
            else if (salBruto <= 1050)
            {
                aliqINSS = 0.0865;
            }
            else if (salBruto <= 1400.77)
            {
                aliqINSS = 0.09;
            }
            else if (salBruto <= 2801.56)
            {
                aliqINSS = 0.11;
            }
            else
            {
                aliqINSS = 0; //codigo para representar o teto
            }

            //calcular a aliquota do IRPF
            if (salBruto <= 1257.12)
            {
                aliqIRPF = 0; //codigo para representar isenção
            }
            else if (salBruto <= 2512.08)
            {
                aliqIRPF = 0.15;
            }
            else
            {
                aliqIRPF = 0.275;
            }

            //calcular desconto do INSS
            if (aliqINSS != 0)
                descINSS = salBruto * aliqINSS;
            else
                descINSS = 308.17;

            //calcular desconto do IRPF
            if (aliqIRPF != 0)
                descIRPF = salBruto * aliqIRPF;
            else
                descIRPF = 0;

            //calcular salario familia
            if ((salBruto) <= 435.52)
            {
                salFamilia = 22.33 * (double)qtdeFilhos;
            }
            else if ((salBruto) <= 654.61)
            {
                salFamilia = 15.74 * (double)qtdeFilhos;
            }
            else
            {
                salFamilia = 0;
            }

            //calcular salario liquido
            salLiquido = salBruto - descINSS - descIRPF + salFamilia;

            //imprimir os valores da aliquota do INSS
            if (aliqINSS == 0)
            {
                txtAliqINSS.Text = "teto";
            }
            else
            {
                txtAliqINSS.Text = aliqINSS * 100 + "%";
            }

            //imprimir os valores da aliquota do IRPF
            if (aliqIRPF == 0)
            {
                txtAliqIRPF.Text = "isento";
            }
            else
            {
                txtAliqIRPF.Text = aliqIRPF * 100 + "%";
            }

            //imprimir desconto INSS
            txtDescINSS.Text = descINSS.ToString();

            //imprimir desconto IRPF
            txtDescIRPF.Text = descIRPF.ToString();

            //imprimir salario familia
            txtSalFamilia.Text = salFamilia.ToString();

            //imprimir salario liquido
            txtSalLiquido.Text = salLiquido.ToString();
        }

        private void NupdQtdeFilhos_Validated(object sender, EventArgs e)
        {}

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNome.Clear();
            mskbxSalBruto.Clear();
            nupdQtdeFilhos.Value = 0;
            txtAliqINSS.Clear();
            txtAliqIRPF.Clear();
            txtDescINSS.Clear();
            txtDescIRPF.Clear();
            txtSalFamilia.Clear();
            txtSalLiquido.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
