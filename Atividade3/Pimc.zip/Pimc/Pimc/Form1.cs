﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso;
        double altura;
        double imc;
        string classificação;

        public Form1()
        {
            InitializeComponent();
        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(mskbxPeso, "");
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                errorProvider2.SetError(mskbxPeso, "Peso inválido");
            }
            else
                if (peso <= 0)
                {
                    MessageBox.Show("Peso não pode ser negativo");
                    errorProvider2.SetError(mskbxPeso, "Peso inválido");
                }
        }

        private void MkdbxAltura_Validated(object sender, EventArgs e)
        {

        }

        private void MskbxAltura_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskbxAltura, "");

            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Altura Inválida");
                errorProvider1.SetError(mskbxAltura, "Altura Inválida");
            }
            else
                if (peso <= 0)
                {
                    MessageBox.Show("Altura não pode ser negativa");
                    errorProvider1.SetError(mskbxAltura, "Altura Inválida");
                }
                
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura) && !double.TryParse(mskbxPeso.Text, out peso))
            {
                if (altura < 0 || peso < 0)
                    MessageBox.Show("Valores não podem ser negativos");
            }
            else
            {
                imc = peso / Math.Pow(altura, 2);
                imc = Math.Round(imc, 1);
                //txtImc.Text = imc.ToString();

                if (imc < 18.5)
                    classificação = "Magreza";
                else
                    if (imc < 24.9)
                        classificação="Normal";
                    else
                        if (imc < 29.9)
                            classificação = "Sobrepeso";
                        else
                            if (imc < 39.9)
                                classificação = "Obesidade";
                            else
                                classificação = "Obesidade Grave";

                txtImc.Text = imc.ToString()+" "+classificação;

                /*if (imc < 18.5)
                    MessageBox.Show("Magreza");
                else
                    if (imc < 24.9)
                        MessageBox.Show("Normal");
                    else
                        if(imc < 29.9)
                            MessageBox.Show("Sobrepeso");
                        else
                            if(imc < 39.9)
                                MessageBox.Show("Obesidade");
                            else
                                MessageBox.Show("Obesidade Grave");*/

            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
