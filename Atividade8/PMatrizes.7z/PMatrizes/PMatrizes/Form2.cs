﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {

            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[9];
            string saida, aux = "";
            int[] tamanhos = new int[9];

            for (int i = 0; i <= nomes.Length-1; i++)
            {
                nomes[i] = Interaction.InputBox("Digite um nome", "Entrade de dados");

                if (double.TryParse(nomes[i], out double verific))
                {
                    MessageBox.Show("O nome não pode ter numeros");
                    i--;
                }
                else
                {
                    aux = nomes[i].Replace(" ", string.Empty);
                    tamanhos[i] = aux.Length;
                    saida = "O nome: " + nomes[i] + " tem " + tamanhos[i].ToString() + " letras\n";
                    lsbxSaida.Items.Add(saida);

                }


            }
        }
    }
}
