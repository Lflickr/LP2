﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using Microsoft.VisualBasic;

namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string aux = "";
            string saida = "";

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Digite um numero", "Entrada de dados");

                if (!int.TryParse(aux, out vetor[i]))
                {
                    MessageBox.Show("Numero Invalido");
                    i--;
                }
                else
                {
                    saida =vetor[i] +"\n"+ saida;
                }
            }
            MessageBox.Show(saida);

            /*for (int j = 19; j >= 0; j--)
            {
                aux += vetor[j] + "\n";
            }
            MessageBox.Show(aux);*/

            /*Array.Reverse(vetor);
            aux = "";
            foreach (var c in vetor)
                aux += c + '\n';
            MessageBox.Show(aux);*/
        }

        private void BtnExercicio2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string aux = "";
            double[] medias = new double[20];
            string saida = "";

            for (int i = 0; i < 20; i++)
                for (int j = 0; j < 3; j++)
                {
                    aux = Interaction.InputBox($"Digite a nota {(j+1)} do aluno {(i+1)}", "Entrada de dados");

                    if(!double.TryParse(aux, out notas[i,j]))
                    {
                        MessageBox.Show("O valor deve ser numerico");
                        j--;
                    }
                    else if(notas[i,j] < 0 || notas[i,j] > 10)
                    {
                        MessageBox.Show("o valor deve estar entre 0 e 10");
                        j--;
                    }
                }
            for (int i = 0; i < 20; i++)
            {
                medias[i] = 0;

                for (int j = 0; j < 3; j++)
                {
                    medias[i] += notas[i, j];
                }

                medias[i] = medias[i] / 3;
            }

            for (int i = 0; i < 20; i++)
            {
                saida += "Aluno"+ (i+1) + ": "+ medias[i] + "\n";
            }
            MessageBox.Show(saida.ToString());

        }

        private void BtnExercicio3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby" };
            Int32 i, total = 0;
            Int32 n = Alunos.Length;
            for (i = 0; i < n - 1; i++)
            {
                total += Alunos[i].Length;
            }
            MessageBox.Show(total.ToString());
        }

        private void BtnExercicio4_Click(object sender, EventArgs e)
        {
            ArrayList Nomes = new ArrayList(new string[] { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" });
            string saida = "";
            //Nomes = { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais"};
            Nomes.Remove("Otávio");
            foreach (string aux in Nomes)
                saida += aux + " \n";
            MessageBox.Show(saida);
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            /*if (Application.OpenForms.OfType<frmEx5>().Count() > 0)
            {
                MessageBox.Show("Form ja exixtente");
                Application.OpenForms["frmEx5"].BringToFront();
            }
            else
            {
                frmEx5 frm2 = new frmEx5();

                frm2.ShowDialog();
            }*/
            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }

        private void btnExercicio5_Click_1(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();

            frm2.ShowDialog();
        }
    }
}
