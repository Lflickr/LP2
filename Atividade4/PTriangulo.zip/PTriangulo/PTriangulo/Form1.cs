﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double ladoA;
        double ladoB;
        double ladoC;
        string tipoTriang;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(txtLadoA, "");

            if (!double.TryParse(txtLadoA.Text, out ladoA))
            {
                MessageBox.Show("Valor Inválido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider1.SetError(txtLadoA, "Valor Inválido");
            }
            else
                if(ladoA <= 0)
                    MessageBox.Show("O lado não pode ser negativo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(txtLadoB, "");

            if (!double.TryParse(txtLadoB.Text, out ladoB))
            {
                MessageBox.Show("Valor Inválido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider2.SetError(txtLadoB, "Valor Inválido");
            }
            else
                if (ladoB <= 0)
                MessageBox.Show("O lado não pode ser negativo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(txtLadoC, "");

            if (!double.TryParse(txtLadoC.Text, out ladoC))
            {
                MessageBox.Show("Valor Inválido", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                errorProvider3.SetError(txtLadoC, "Valor Inválido");
            }
            else
                if (ladoC <= 0)
                    MessageBox.Show("O lado não pode ser negativo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(double.TryParse(txtLadoA.Text, out ladoA) && 
                double.TryParse(txtLadoB.Text, out ladoB) && 
                double.TryParse(txtLadoC.Text, out ladoC))
            {
                if(Math.Abs(ladoB-ladoC) < ladoA && ladoA < (ladoB+ladoC) &&
                    Math.Abs(ladoA-ladoC) < ladoB && ladoB < (ladoA+ladoC) &&
                    Math.Abs(ladoA-ladoB) < ladoC && ladoC < (ladoA+ladoB)) 
                {
                    if (ladoA == ladoB && ladoB == ladoC)
                        txtTipo.Text = "Triangulo Equilátero";
                    else
                    { 
                        if (ladoA != ladoB && ladoB != ladoC && ladoC != ladoA)
                            txtTipo.Text = "Triangulo Escaleno";
                        else
                            txtTipo.Text = "Triangulo Isoceles";
                    }
                    
                }
                else
                    MessageBox.Show("os valores não pertencem aos lados de um triangulo", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("Valores inválidos", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
