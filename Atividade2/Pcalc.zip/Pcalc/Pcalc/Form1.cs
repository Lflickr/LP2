﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double num1, num2, result;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Clear();
            txtNum2.Clear();
            txtResult.Clear();

            txtNum1.Focus();
            result = 0;
        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out num2))
            {
                MessageBox.Show("Valor inválido");
                txtNum2.Focus();
            }
        }

        private void TxtResult_Validated(object sender, EventArgs e)
        {

        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            result = num1 + num2;
            txtResult.Text = result.ToString();
        }

        private void BtnSub_Click(object sender, EventArgs e)
        {
            result = num1 - num2;
            txtResult.Text = result.ToString();
        }

        private void BtnDiv_Click(object sender, EventArgs e)
        {
            if (num2 != 0)
            {
                result = num1 / num2;
                txtResult.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("Denominador inválido","Erro",MessageBoxButtons.OK,MessageBoxIcon.Error);
                txtNum2.Focus();
            }
        }

        private void BtnMply_Click(object sender, EventArgs e)
        {
            result = num1 * num2;
            txtResult.Text = result.ToString();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            DialogResult escolha;
            escolha = MessageBox.Show("Tem certeza que quer fechar?","Saida",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (escolha == DialogResult.Yes)
            {
                Close();
            }
            else
            {
                MessageBox.Show(":)");
            }
        }

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum1.Text, out num1))
            {
                MessageBox.Show("Valor inválido");
                txtNum1.Focus();
            }
        }
    }
}
