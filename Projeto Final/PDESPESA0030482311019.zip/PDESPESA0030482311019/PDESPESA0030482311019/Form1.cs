﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;


namespace PDESPESA0030482311019
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                // aqui a conexão vai depende da sua máquina da escola ou particular
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=LP2;User ID=BD2311028; PASSWORD=Akashinhosenpai123");
                conexao.Open();
            } 
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros Erros =/" + ex.Message);
            }
        }

        private void CadastroDespesasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmDespesa>().Count() > 0)
            {
                Application.OpenForms["frmDespesa"].BringToFront();
            }
            else
            {
                frmDespesa FrmDesp = new frmDespesa();
                FrmDesp.MdiParent = this;
                FrmDesp.WindowState = FormWindowState.Maximized;
                FrmDesp.Show();
            }
        }

        private void SobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre FrmSobre = new frmSobre();
                FrmSobre.MdiParent = this;
                FrmSobre.WindowState = FormWindowState.Maximized;
                FrmSobre.Show();
            }
        }
    }
}
