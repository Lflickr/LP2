﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rctxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnEspBranco = new System.Windows.Forms.Button();
            this.btnContLetras = new System.Windows.Forms.Button();
            this.lblFrase = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rctxtFrase
            // 
            this.rctxtFrase.Location = new System.Drawing.Point(75, 41);
            this.rctxtFrase.Name = "rctxtFrase";
            this.rctxtFrase.Size = new System.Drawing.Size(638, 177);
            this.rctxtFrase.TabIndex = 0;
            this.rctxtFrase.Text = "";
            // 
            // btnContNum
            // 
            this.btnContNum.Location = new System.Drawing.Point(154, 306);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(109, 64);
            this.btnContNum.TabIndex = 1;
            this.btnContNum.Text = "Contar numeros";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.BtnContNum_Click);
            // 
            // btnEspBranco
            // 
            this.btnEspBranco.Location = new System.Drawing.Point(335, 306);
            this.btnEspBranco.Name = "btnEspBranco";
            this.btnEspBranco.Size = new System.Drawing.Size(109, 64);
            this.btnEspBranco.TabIndex = 2;
            this.btnEspBranco.Text = "Primeiro caractere branco";
            this.btnEspBranco.UseVisualStyleBackColor = true;
            this.btnEspBranco.Click += new System.EventHandler(this.BtnEspBranco_Click);
            // 
            // btnContLetras
            // 
            this.btnContLetras.Location = new System.Drawing.Point(516, 306);
            this.btnContLetras.Name = "btnContLetras";
            this.btnContLetras.Size = new System.Drawing.Size(109, 64);
            this.btnContLetras.TabIndex = 3;
            this.btnContLetras.Text = "Contar Letras";
            this.btnContLetras.UseVisualStyleBackColor = true;
            this.btnContLetras.Click += new System.EventHandler(this.BtnContLetras_Click);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(13, 51);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(36, 13);
            this.lblFrase.TabIndex = 4;
            this.lblFrase.Text = "Frase:";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnContLetras);
            this.Controls.Add(this.btnEspBranco);
            this.Controls.Add(this.btnContNum);
            this.Controls.Add(this.rctxtFrase);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rctxtFrase;
        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnEspBranco;
        private System.Windows.Forms.Button btnContLetras;
        private System.Windows.Forms.Label lblFrase;
    }
}