﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void BtnSorteio_Click(object sender, EventArgs e)
        {
            int num1, num2;

            if(!int.TryParse(txtNum1.Text, out num1) || !int.TryParse(txtNum2.Text, out num2))
                MessageBox.Show("Numeros Invalidos");
            else
            {
                if((num1 < 0)|| (num2 <= 0) || (num1 > num2))
                    MessageBox.Show("Numero 2 deve ser maior que o numero 1");
                else
                {
                    Random sorteio = new Random();
                    int aleatorio = sorteio.Next(num1, num2);
                    MessageBox.Show("Numero aleatório:"+aleatorio);
                }
            }

        }
    }
}
