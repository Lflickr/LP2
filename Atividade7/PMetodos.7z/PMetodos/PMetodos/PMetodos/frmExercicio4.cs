﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnContNum_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach (var c in rctxtFrase.Text)
            {
                if (char.IsNumber(c))
                    cont++;
            }
            MessageBox.Show("nº de digitos: "+ cont);
        }

        private void BtnContLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;
            for (int i = 0; i < rctxtFrase.Text.Length; i++)
            {
                if (char.IsLetter(rctxtFrase.Text[i]))
                    cont++;
            }
            MessageBox.Show($"nº de letras: {cont}");

        }

        private void BtnEspBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;
            int cont = 0;
            while(cont < rctxtFrase.Text.Length)
            {
                if(char.IsWhiteSpace(rctxtFrase.Text[cont]))
                {
                    posicao = cont + 1;
                    break;
                }
                cont++;
            }
            MessageBox.Show("A posição do primeiro espaço em branco é: "+posicao);
        }
    }
}
