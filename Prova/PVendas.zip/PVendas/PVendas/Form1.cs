﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            lsbxSaida.Items.Clear();
            Double[,] vendas = new double[3, 4];
            Double[] totalMes = new double[3];
            Double totalzao = 0;
            String[,] aux = new string[3, 4];
            int i, j;

            for (i = 0; i < 3; i++)
            {
                totalMes[i] = 0;

                for (j = 0; j < 4; j++)
                {
                    aux[i, j] = Interaction.InputBox("Digite o valor", "Entrade de dados");

                    if (!double.TryParse(aux[i, j], out vendas[i, j]))
                    {
                        MessageBox.Show("Valor invalido");
                        j--;

                    }
                    else if (vendas[i, j] < 0)
                    {
                            MessageBox.Show("O valor não pode ser negativo");
                            j--;
                    }
                    else
                    {
                        totalMes[i] += vendas[i, j];
                        totalzao += vendas[i, j];
                    }
                        
                    

                }
                
            }
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    lsbxSaida.Items.Add("Total do mes: " + (i + 1) + " Semana: " + (j + 1) + " " + vendas[i, j].ToString("N2") + "\n");  
                }
                lsbxSaida.Items.Add(">> Total Mes: " + totalMes[i].ToString("C2") +"\n");
                lsbxSaida.Items.Add("--------------------------");
            }
            lsbxSaida.Items.Add(">> Total Geral: " + totalzao.ToString("C2") + "\n");





        }
    }


}       
    

